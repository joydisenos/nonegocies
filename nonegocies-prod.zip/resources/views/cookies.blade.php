@extends('layouts.master')
@section('content')
<header class="page">
	<div class="container">
	<h1 class="animated fadeInLeft">Política de Cookies</h1>
	<p class="animated fadeInDown">Si tienes alguna duda o necesitas que te ayudemos<br>ponte en contacto con atención al cliente.</p>
	</div>
</header>
<section class="gray">
	<div class="container">
		{!! $legal !!}
	</div>
</section>
@endsection