@extends('layouts.master')

@section('content')
<header class="page">
	<div class="container">
	<h1 class="animated fadeInLeft">Página no Disponible</h1>
	<a href="{{ url('/') }}" class="btn btn-primary">Inicio</a>
	</div>
</header>
@endsection
