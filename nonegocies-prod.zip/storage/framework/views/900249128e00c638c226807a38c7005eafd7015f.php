<?php if(session('status')): ?>
    <script>
        toastr.success("<?php echo e(session('status')); ?>")
    </script>
<?php endif; ?>