<?php $__env->startSection('content'); ?>
<header class="page">
	<div class="container">
	<h1 class="animated fadeInLeft">Sesión Caducada</h1>
	<a href="<?php echo e(url('/')); ?>" class="btn btn-primary">Inicio</a>
	</div>
</header>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>