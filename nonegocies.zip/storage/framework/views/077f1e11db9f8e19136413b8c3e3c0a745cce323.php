<?php $__env->startSection('content'); ?>
<header class="page">
	<div class="container">
	<h1 class="animated fadeInLeft">Política de Cookies</h1>
	<p class="animated fadeInDown">Si tienes alguna duda o necesitas que te ayudemos<br>ponte en contacto con atención al cliente.</p>
	</div>
</header>
<section class="gray">
	<div class="container">
		<?php echo $legal; ?>

	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>