<?php $__env->startSection('content'); ?>
<style>
	p{
		font-size: 13px !important;
	    color: dimgray !important;
	    line-height: 1.5 !important
	}
</style>
<header class="page">
	<div class="container">
	<h1 class="animated fadeInLeft">Términos y Condiciones</h1>
	<p class="animated fadeInDown">Si tienes alguna duda o necesitas que te ayudemos<br>ponte en contacto con atención al cliente.</p>
	</div>
</header>
<section class="gray">
	<div class="container">
			<?php echo $legal; ?>

	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>